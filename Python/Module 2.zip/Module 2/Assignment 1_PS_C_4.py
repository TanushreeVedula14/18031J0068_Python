# Write a program such that it takes string as a input and outputs the reverse
# of the string.

str = input("String = ")

rev = str[::-1]

print(rev)
