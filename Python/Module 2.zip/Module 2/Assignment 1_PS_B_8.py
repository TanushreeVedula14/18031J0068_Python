
dict = {1:'one',2:'two'}

print(dict[1])
