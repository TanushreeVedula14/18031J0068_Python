str = input()

dict = {}

for i in str:
    if i in dict:
        dict[i] += 1
    else:
        dict[i] = 1
print(dict)
        
dict1 = {}

for key,value in str:
    if dict1[value] in dict1.items():
        dict1[value] += 1
