# Check whether an element exists in a given tuple using predefined function.

t = ("abc",1,5.2,"hello",100)

print("abc" in t)
print(100 in t)
print(500 in t)


