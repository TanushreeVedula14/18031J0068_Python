# Write a python script to find the minimum, maximum, length
# and convert the tuple into a list using predefined functions.

t = (1,99,101,52,96,73)

print("Max = "+str(max(t)))
print("Min = "+str(min(t)))
print("Len = "+str(len(t)))
print("List = "+str(list(t)))
