# When two integer lists 'a' and 'b' are given, create a new list containing
# middle elements of the given lists 'a' and 'b'.

list1 = [1,3,5,7,9]
list2 = [2,4,6,8,10]

list3 = list1[1:4]+list2[1:4]
print(list3)

