# Check whether two integer lists are similar using predefined function.

list1 = [1,2,3,4,5]
list2 = [1,2,3,4,5]

print(list1 == list2)
