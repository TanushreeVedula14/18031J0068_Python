#Concatenate two tuple and print them.

A = ('Hello','Tanushree')
B = ('How','are','you?')

print(A+B)
