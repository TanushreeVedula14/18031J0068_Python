# Create a tuple with weekdays as elements. Print the elements of tuple using iterator.

weekDays = ('Monday','Tuesday','Wednesday','Thursday','Friday')

for days in weekDays:
    print(days)
