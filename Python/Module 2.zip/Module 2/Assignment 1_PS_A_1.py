#Print Multiplication Table

number = int(input())
upto = int(input())

for i in range(upto):
    result = number * (i+1)
    print(result)
